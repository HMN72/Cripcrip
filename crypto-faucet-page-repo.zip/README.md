# Cripcrip 🚀 (FaucetPay + GitHub Pages)

Repositorio oficial de la Faucet de criptomonedas para **Bitcoin (BTC)**, configurado para ejecutarse en **GitHub Pages** con dominio personalizado: `faucet.cripcri.com`.

---

## 📋 Requisitos Previos
1. Una cuenta de [GitHub](https://github.com).
2. Un dominio propio (en Namecheap, GoDaddy, Cloudflare, Hostinger, etc.).
3. Una cuenta de [FaucetPay.io](https://faucetpay.io) para recibir y distribuir pagos.

---

## 🛠️ Paso 1: Configurar el Repositorio en GitHub
1. Crea un nuevo repositorio público en GitHub con el nombre `crypto-faucet-page`.
2. Sube todos los archivos de este paquete (`index.html`, `CNAME`, `README.md`).
3. En GitHub ve a **Settings** > **Pages** > Selecciona la rama `main` (o `master`) y la carpeta `/ (root)`.
4. Haz clic en **Save**.

---

## 🌐 Paso 2: Configurar tu Dominio Personalizado en tu Proveedor DNS

### Caso A: Dominio Principal (ej: `tudominio.com`)
Crea 4 registros **A** apuntando a las IPs oficiales de GitHub Pages:
- **Tipo:** `A` | **Host:** `@` | **Valor:** `185.199.108.153` | **TTL:** Automático
- **Tipo:** `A` | **Host:** `@` | **Valor:** `185.199.109.153` | **TTL:** Automático
- **Tipo:** `A` | **Host:** `@` | **Valor:** `185.199.110.153` | **TTL:** Automático
- **Tipo:** `A` | **Host:** `@` | **Valor:** `185.199.111.153` | **TTL:** Automático

### Caso B: Subdominio (ej: `faucet.cripcri.com`)
Crea 1 registro **CNAME**:
- **Tipo:** `CNAME` | **Host:** `faucet` | **Valor:** `Cripcrip.github.io` | **TTL:** Automático

---

## 🔒 Paso 3: Activar HTTPS en GitHub Pages
1. En GitHub > **Settings** > **Pages**.
2. Verifica que en **Custom domain** aparezca `faucet.cripcri.com`.
3. Marca la casilla **Enforce HTTPS** (puede demorar unos minutos mientras GitHub genera el certificado SSL gratuito).

---

## 💰 Paso 4: Agregar tu Faucet a la Lista Oficial de FaucetPay
Para recibir miles de visitantes diarios de forma gratuita:
1. Inicia sesión en **FaucetPay.io**.
2. Ve a **Faucet Owner Dashboard** > **Add a Faucet**.
3. Ingresa la URL de tu dominio: `https://faucet.cripcri.com`.
4. Elige la moneda **Bitcoin** y especifica tu recompensa de **1e-8 Satoshis**.

---

## 📈 Monetización
- Añade banners de [A-Ads.com](https://a-ads.com) o [Coinzilla](https://coinzilla.com) editando `index.html`.
- Cada vez que un usuario reclame, verá los anuncios y tú generarás ingresos pasivos.
